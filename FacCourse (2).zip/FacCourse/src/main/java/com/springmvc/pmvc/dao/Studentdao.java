package com.springmvc.pmvc.dao;
import java.sql.*;
import java.util.*;
import org.springframework.jdbc.core.*;

import com.sbjjpa.sbjjpa1.Student;
import com.springmvc.pmvc.beans.*;
public class Studentdao {
	JdbcTemplate jdbcTemplate;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	{
		this.jdbcTemplate = jdbcTemplate;
	}
	public int save(Student s) {
		String qry="insert into student values(" + s.getRno() + ",'"+s.getStName() + "')";
		return jdbcTemplate.update(qry);
	}
	public List<Student> getStudents() {
	    String qry = "SELECT * FROM student";
	    return jdbcTemplate.query(qry, new RowMapper<Student>() {
	        public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Student student = new Student();
	            student.setRno(rs.getInt("rollno"));
	            student.setStName(rs.getString("name"));
	            return student;
	        }
	    });
	}


}
